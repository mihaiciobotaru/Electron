#include <bits/stdc++.h>
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

const string PREFIX = "/Users/gareth618/Desktop/Electron/";
// sau "" dacă resursele sunt în același folder

#include "piece.cpp"
#include "circuit.cpp"
#include "snake.cpp"
#include "ui.cpp"
#include "fm.cpp"
#include "window.cpp"

int main() {
    displayGraphics();
    return 0;
}
